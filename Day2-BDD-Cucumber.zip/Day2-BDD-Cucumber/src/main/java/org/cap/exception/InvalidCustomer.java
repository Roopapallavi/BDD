package org.cap.exception;

public class InvalidCustomer extends Exception {
	
	public InvalidCustomer(String msg) {
		super(msg);
	}

}
