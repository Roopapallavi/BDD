package loginForm;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import page.LoginPageBean;

public class LoginPageTest {


	private WebDriver driver;
	private LoginPageBean loginPageBean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\TR2\\chromedriver.exe");
		 driver=new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 loginPageBean=new LoginPageBean(driver);
	}
	
	@Test
	public void check_loginPageNavigation() {
		driver.get("http://localhost:8082/Day4-WalletApp/");
		String pageHeading=loginPageBean.getPageHeading();
		assertTrue(pageHeading.equals("Capg Banking Application"));
		loginPageBean.loginTo_NextPage("88", "Roopa123");
		
	}
@After
public void tearDown() {
	driver.close();
}
}
