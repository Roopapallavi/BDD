package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {
			
					WebDriver driver;
					
					/*private By userName=By.name("userName");
					private By password=By.name("userPwd");
					private By subLogin=By.name("login");*/
					
					@FindBy(name="customerId",how=How.NAME)
					private WebElement userName;
					@FindBy(name="password")
					private WebElement password;
					@FindBy(name="login")
					private WebElement subLogin;
					@FindBy(xpath="//*[@id=\"mainCnt\"]/h1")
					private WebElement pageHeading;
					//private By pageHeading=By.xpath("//*[@id=\"mainCnt\"]/h1");
					public LoginPageBean(WebDriver driver) {
						this.driver=driver;
						PageFactory.initElements(driver, this);
					}
					public void setUserName(String username) {
						//driver.findElement(userName).sendKeys(username);
						userName.sendKeys(username);
					}
					public void setUserpassword(String userpassword) {
						//driver.findElement(password).sendKeys(userpassword);
						password.sendKeys(userpassword);
					}
					public void setSubLogin() {
						//driver.findElement(subLogin).submit();
						subLogin.submit();
						
					}
					public String getPageHeading() {
						return  pageHeading.getText();
								//driver.findElement(pageHeading).getText();
					}
					public void loginTo_NextPage(String userName,String Password) {
						this.setUserName(userName);
						this.setUserpassword(Password);
						this.setSubLogin();
					}
}
