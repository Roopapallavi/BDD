package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {
				
				@RequestMapping("/")
				public String studentRegistrationForm() {
					return "studentRegistrationForm";
					
				}
				
				@RequestMapping("/studentRegistrationForm")
				public String payDetails() {
					return "paymentDetails";
					
				}
				
				@RequestMapping("/paymentDetails")
				public String paymentDetails() {
					return "paymentDetails";
					
				}
}
