package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentPageBean {
				
				WebDriver driver;
				
				@FindBy(name="HolderName")
				private WebElement holdername;
				@FindBy(name="D/Cno")
				private WebElement cardnum;
				@FindBy(name="CVVNumber")
				private WebElement cvvnum;
				@FindBy(name="expiryDate")
				private WebElement expdate;
				@FindBy(name="payment")
				private WebElement Pay;
				
				public PaymentPageBean(WebDriver driver) {
					this.driver=driver;
					PageFactory.initElements(driver, this);
				}
				
				public void setName(String name) {
					holdername.sendKeys(name);
				}
				public void setCardNum(String num) {
					cardnum.sendKeys(num);
				}
				public void setCVVNum(String cvv) {
					cvvnum.sendKeys(cvv);
				}
				public void setExDate(String exDate) {
					expdate.sendKeys(exDate);
				}
				public void setPayment() {
					Pay.submit();
				}
				
				public void NavigateTo_Student(String name,String num,String cvv,String exDate) {
					this.setName(name);
					this.setCardNum(num);
					this.setCVVNum(cvv);
					this.setExDate(exDate);
					this.setPayment();
				}
}
