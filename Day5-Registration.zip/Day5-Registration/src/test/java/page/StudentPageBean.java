package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class StudentPageBean {
		
				WebDriver driver;
				
				@FindBy(name="firstName")
				private WebElement firstname;
				@FindBy(name="lastName")
				private WebElement lastname;
				@FindBy(name="address")
				private WebElement address;
				@FindBy(name="city")
				private WebElement city;
				@FindBy(name="state")
				private WebElement state;
				
				private WebElement gender;
				@FindBy(name="course")
				private WebElement course;
				@FindBy(name="Mobile")
				private WebElement mobile;
				@FindBy(name="next")
				private WebElement nextPage;
				
				public StudentPageBean(WebDriver driver) {
					this.driver=driver;
					PageFactory.initElements(driver, this);
				}
				
				public void setFirstName(String fname) {
					firstname.sendKeys(fname);
				}
				public void setLastName(String lname) {
					lastname.sendKeys(lname);
				}
				public void setAddress(String add) {
					address.sendKeys(add);
				}
				public void setCity(String cty) {
					city.sendKeys(cty);
				}
				public void setState(String stat) {
					state.sendKeys(stat);
				}
				public void setGender(String gen) {
					WebElement g=driver.findElement(By.id(gen));
					g.click();
				}
				public void setCourse(String crsc) {
					course.sendKeys(crsc);
				}
				public void setMobile(String mobnum) {
					mobile.sendKeys(mobnum);
				}
				
				public void setNextPage() {
					nextPage.submit();
				}
				
			public void MoveTo_NextPage(String fname,String lname,String add,
						String cty,String stat,String gen,String crsc,String mobnum)
			{
					this.setFirstName(fname);
					this.setLastName(lname);
					this.setAddress(add);
					this.setCity(cty);
					this.setState(stat);
					this.setGender(gen);
					this.setCourse(crsc);
					this.setMobile(mobnum);
					this.setNextPage();
			
				}
				
}
