package registration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.PaymentPageBean;
import page.StudentPageBean;

public class stepDef {
	
			
	private WebDriver driver;
	private StudentPageBean studentPageBean;
	private PaymentPageBean payPageBean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\TR2\\chromedriver.exe");
		 driver=new ChromeDriver();
		 studentPageBean=new StudentPageBean(driver);
		 payPageBean=new PaymentPageBean(driver);
	}
				
	@Given("^Student Registration form and payment details form$")
	public void student_Registration_form() throws Throwable {
		driver.get("http://localhost:8082/Day5-Registration/");
	}

	@When("^valid student details are entered$")
	public void valid_student_details_are_entered() throws Throwable {
			studentPageBean.MoveTo_NextPage("Swaroopa","Sannidhi","BVRM","Bhimavaram","Andhra Pradesh","f","BE","8099060888");

	}

	@Then("^navigate to paymentDetails page$")
	public void navigate_to_paymentDetails_page() throws Throwable {
			//driver.switchTo().alert().accept();
	}
	
	/*@Given("^Student Registration form and payment details form$")
	public void student_Registration_form_and_payment_details_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}*/

	@When("^vaild payment details are entered$")
	public void vaild_payment_details_are_entered() throws Throwable {
	    payPageBean.NavigateTo_Student("SWAROOPA", "1236547896541236", "391", "10/02/2018");
	}

	@Then("^navigate to StudentRegistration page$")
	public void navigate_to_StudentRegistration_page() throws Throwable {
	   
	}
}